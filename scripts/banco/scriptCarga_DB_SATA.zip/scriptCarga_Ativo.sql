--
-- PostgreSQL database dump
--

-- Dumped from database version 9.0.4
-- Dumped by pg_dump version 9.0.1
-- Started on 2011-04-25 16:35:15

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1502 (class 1259 OID 16424)
-- Dependencies: 5
-- Name: Ativo; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "Ativo" (
    "codigoAtivo" character varying(10) NOT NULL,
    "nomeEmpresa" character varying(500)
);


ALTER TABLE public."Ativo" OWNER TO postgres;

--
-- TOC entry 1783 (class 0 OID 16424)
-- Dependencies: 1502
-- Data for Name: Ativo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "Ativo" ("codigoAtivo", "nomeEmpresa") FROM stdin;
ABCB4	ABC BRASIL PN
BBAS3	BRASIL ON
BBDC4	BRADESCO PN
BRFS3	BRF FOODS ON
BVMF3	BMFBOVESPA ON
CCRO3	CCR SA ON
CIEL3	CIELO ON
CMIG4	CEMIG PN
CRUZ3	SOUZA CRUZ ON
CSNA3	SID NACIONAL ON
CYRE3	CYRELA REALT ON
ELET3	ELETROBRAS ON
EMBR3	EMBRAER ON
FIBR3	FIBRIA ON
GFSA3	GAFISA ON
GGBR4	GERDAU PN
GOLL4	GOL PN
HYPE3	HYPERMARCAS ON
ITSA4	ITAUSA PN
ITUB4	ITAUUNIBANCO PN
JBSS3	JBS ON
LAME4	LOJAS AMERIC PN
LREN3	LOJAS RENNER ON
MMXM3	MMX MINER ON
MRVE3	MRV ON
NATU3	NATURA ON
OGXP3	OGX PETROLEO ON
PCAR4	P.ACUCAR-CBD PN
PDGR3	PDG REALT ON
PETR4	PETROBRAS PN
RDCD3	REDECARD ON
RSID3	ROSSI RESID ON
TAMM4	TAM S/A PN
TCSL4	TIM PART S/A PN
TNLP4	TELEMAR PN
USIM5	USIMINAS PNA
VALE5	VALE PNA
VIVO4	VIVO PN
\.


--
-- TOC entry 1782 (class 2606 OID 16431)
-- Dependencies: 1502 1502
-- Name: Ativo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "Ativo"
    ADD CONSTRAINT "Ativo_pkey" PRIMARY KEY ("codigoAtivo");


-- Completed on 2011-04-25 16:35:16

--
-- PostgreSQL database dump complete
--

